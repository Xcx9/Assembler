#include <cstdio>

extern "C" int f1(int x, int y);

static int f1_cpp(int x, int y)
{
    return 12 + x + y;
}

int main()
{
    int x = 0;
    int y = 0;

    std::printf("Enter x y: ");
    std::scanf("%d %d", &x, &y);

    const int asm_result = f1(x, y);
    const int cpp_result = f1_cpp(x, y);

    std::printf("asm = %d\n", asm_result);
    std::printf("cpp = %d\n", cpp_result);
    std::printf("match = %s\n", (asm_result == cpp_result) ? "yes" : "no");

    return 0;
}
