#include <cstdio>

extern "C" double f2(double x, double y);

static double f2_cpp(double x, double y)
{
    return x / y;
}

int main()
{
    double x = 0.0;
    double y = 1.0;

    std::printf("Enter x y: ");
    std::scanf("%lf %lf", &x, &y);

    const double asm_result = f2(x, y);
    const double cpp_result = f2_cpp(x, y);

    std::printf("asm = %.10f\n", asm_result);
    std::printf("cpp = %.10f\n", cpp_result);
    std::printf("match = %s\n", (asm_result == cpp_result) ? "yes" : "no");

    return 0;
}
