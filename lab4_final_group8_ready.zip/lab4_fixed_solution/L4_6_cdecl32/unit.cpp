#include <cstdio>

extern "C" int f6(int a1, int a2, int a3, int a4,
                  int a5, int a6, int a7, int a8)
{
    std::printf("a1 = %d\n"
                "a2 = %d\n"
                "a3 = %d\n"
                "a4 = %d\n"
                "a5 = %d\n"
                "a6 = %d\n"
                "a7 = %d\n"
                "a8 = %d\n",
                a1, a2, a3, a4, a5, a6, a7, a8);

    return a8;
}
