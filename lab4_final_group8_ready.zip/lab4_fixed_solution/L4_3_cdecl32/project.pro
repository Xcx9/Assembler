TEMPLATE = app
CONFIG += console c++17
CONFIG -= app_bundle
CONFIG -= qt

QMAKE_CXXFLAGS += -m32
QMAKE_LFLAGS += -m32

SOURCES += main.S
