#include <cstdio>

int main()
{
    short i16 = 0;
    int i32 = 0;
    long long i64 = 0;
    float f32 = 0.0f;
    double f64 = 0.0;

    std::scanf("%hd %d %lld %f %lf", &i16, &i32, &i64, &f32, &f64);

    std::printf("i16 = %hd\n"
                "i32 = %d\n"
                "i64 = %lld\n"
                "f32 = %f\n"
                "f64 = %lf\n",
                i16, i32, i64, f32, f64);

    return 0;
}
