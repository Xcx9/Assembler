Lab 5, team number 8, Qt 6.7.3/qmake + Desktop Qt MinGW 64-bit.

Open lab5_team8_ready.pro in Qt Creator and build as a console application.
The assembly source is lab5.S. It is compiled by qmake through gcc
-x assembler-with-cpp, so it is compatible with MinGW/GNU assembler.

Implemented variants:
Lab5.1 = 2: z = x + y; w = 1 iff signed overflow OF occurred.
Lab5.2 = 2: unsigned z = (x > -3), C/C++ unsigned comparison semantics.
Lab5.3 = 2: signed z = (x > -3).
Lab5.4 = 2: float z = (x > -3), SSE comiss only; no AVX/SSE mixing.
Lab5.5 = 2: cmovCC + cmp; x - 2 is computed by one lea for the bonus.
Lab5.6 = 2: first N odd non-negative numbers are written to an array.
Lab5.7 = 2: first N odd non-negative numbers are printed without an array;
              implemented as a complete assembly function.
Lab5.8 = 2: sa returns the 0-based index of the maximum double element.
Lab5.9 = 3: mre replaces the main diagonal of a flat int matrix by -1.

Penalty-related choices:
- no inline assembly clobber lists are used;
- no local variables are stored in the data segment;
- no loop*, jcx*, or jecx* instructions are used;
- matrix storage is a contiguous vector<int32_t>, not an array of row pointers;
- all non-volatile registers modified by the assembly printf loop are saved/restored;
- all dynamic memory is managed by std::vector.
