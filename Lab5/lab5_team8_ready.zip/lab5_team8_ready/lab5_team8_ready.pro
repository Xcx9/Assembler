QT -= gui

TEMPLATE = app
TARGET = lab5_team8_ready
CONFIG += console c++17
CONFIG -= app_bundle

SOURCES += main.cpp

ASM_SOURCES += lab5.S

asm_compiler.name = Assembling ${QMAKE_FILE_IN}
asm_compiler.input = ASM_SOURCES
asm_compiler.output = ${QMAKE_VAR_OBJECTS_DIR}${QMAKE_FILE_BASE}$${first(QMAKE_EXT_OBJ)}
asm_compiler.commands = $$QMAKE_CC -x assembler-with-cpp -c ${QMAKE_FILE_IN} -o ${QMAKE_FILE_OUT}
asm_compiler.variable_out = OBJECTS
asm_compiler.CONFIG += target_predeps
QMAKE_EXTRA_COMPILERS += asm_compiler
