#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <limits>
#include <vector>

struct Lab5_1_Result
{
    std::int32_t z;
    std::int32_t w;
    std::uint8_t cf;
    std::uint8_t of;
    std::uint8_t sf;
    std::uint8_t zf;
    std::uint8_t af;
    std::uint8_t pf;
};

static_assert(offsetof(Lab5_1_Result, z) == 0);
static_assert(offsetof(Lab5_1_Result, w) == 4);
static_assert(offsetof(Lab5_1_Result, cf) == 8);
static_assert(offsetof(Lab5_1_Result, of) == 9);
static_assert(offsetof(Lab5_1_Result, sf) == 10);
static_assert(offsetof(Lab5_1_Result, zf) == 11);
static_assert(offsetof(Lab5_1_Result, af) == 12);
static_assert(offsetof(Lab5_1_Result, pf) == 13);
static_assert(sizeof(Lab5_1_Result) == 16);

extern "C" {
void lab5_1(std::int32_t x, std::int32_t y, Lab5_1_Result *result);
std::int32_t lab5_2(std::uint32_t x);
std::int32_t lab5_3(std::int32_t x);
std::int32_t lab5_4(float x);
std::uint32_t lab5_5(std::uint32_t x);
void lab5_6(std::int32_t *p, std::size_t n);
void lab5_7(std::size_t n);
std::size_t sa(void *p, std::size_t n, double x);
void mre(void *pM, std::size_t n);
}

static void printArray(const std::vector<std::int32_t> &a)
{
    for (std::int32_t value : a) {
        std::cout << value << ' ';
    }
    std::cout << '\n';
}

static void printMatrix(const std::vector<std::int32_t> &m, std::size_t n)
{
    for (std::size_t i = 0; i < n; ++i) {
        for (std::size_t j = 0; j < n; ++j) {
            std::cout << std::setw(5) << m[i * n + j];
        }
        std::cout << '\n';
    }
}

static bool readSize(const char *name, std::size_t &value)
{
    long long signedValue = 0;
    std::cout << name << " = ";
    if (!(std::cin >> signedValue)) {
        return false;
    }
    if (signedValue < 0) {
        std::cout << name << " must be non-negative\n";
        return false;
    }

    value = static_cast<std::size_t>(signedValue);
    return true;
}

static void task1()
{
    std::int32_t x = 0;
    std::int32_t y = 0;
    std::cout << "x = ";
    std::cin >> x;
    std::cout << "y = ";
    std::cin >> y;

    Lab5_1_Result r{};
    lab5_1(x, y, &r);

    std::cout << "z = x + y = " << r.z << '\n';
    std::cout << "w = " << r.w << " (1, если было знаковое переполнение OF)\n";
    std::cout << "CF=" << static_cast<int>(r.cf)
              << " OF=" << static_cast<int>(r.of)
              << " SF=" << static_cast<int>(r.sf)
              << " ZF=" << static_cast<int>(r.zf)
              << " AF=" << static_cast<int>(r.af)
              << " PF=" << static_cast<int>(r.pf) << '\n';
}

static void task2()
{
    std::uint32_t x = 0;
    std::cout << "unsigned x = ";
    std::cin >> x;
    std::cout << "z = (x > -3) = " << lab5_2(x) << '\n';
}

static void task3()
{
    std::int32_t x = 0;
    std::cout << "signed x = ";
    std::cin >> x;
    std::cout << "z = (x > -3) = " << lab5_3(x) << '\n';
}

static void task4()
{
    float x = 0.0f;
    std::cout << "float x = ";
    std::cin >> x;
    std::cout << "z = (x > -3) = " << lab5_4(x) << '\n';
}

static void task5()
{
    std::uint32_t x = 0;
    std::cout << "unsigned x = ";
    std::cin >> x;

    const std::uint32_t z = lab5_5(x);
    std::cout << "z = " << z
              << " (signed view: " << static_cast<std::int32_t>(z) << ")\n";
}

static void task6()
{
    std::size_t n = 0;
    if (!readSize("N", n)) {
        return;
    }

    std::vector<std::int32_t> a(n);
    lab5_6(a.data(), a.size());
    printArray(a);
}

static void task7()
{
    std::size_t n = 0;
    if (!readSize("N", n)) {
        return;
    }

    std::cout.flush();
    lab5_7(n);
}

static void task8()
{
    std::size_t n = 0;
    if (!readSize("N", n)) {
        return;
    }

    std::vector<double> a(n);
    for (std::size_t i = 0; i < n; ++i) {
        std::cout << "a[" << i << "] = ";
        if (!(std::cin >> a[i])) {
            return;
        }
    }

    const std::size_t index = sa(a.data(), a.size(), 0.0);
    if (index == std::numeric_limits<std::size_t>::max()) {
        std::cout << "array is empty\n";
        return;
    }

    std::cout << "index = " << index << "\nmax = " << a[index] << '\n';
}

static void task9()
{
    std::size_t n = 0;
    if (!readSize("N", n)) {
        return;
    }

    if (n != 0 && n > std::numeric_limits<std::size_t>::max() / n) {
        std::cout << "matrix is too large\n";
        return;
    }

    std::vector<std::int32_t> m(n * n);
    for (std::size_t i = 0; i < n; ++i) {
        for (std::size_t j = 0; j < n; ++j) {
            std::cout << "M[" << i << "][" << j << "] = ";
            if (!(std::cin >> m[i * n + j])) {
                return;
            }
        }
    }

    std::cout << "Before:\n";
    printMatrix(m, n);
    mre(m.data(), n);
    std::cout << "After:\n";
    printMatrix(m, n);
}

int main()
{
    std::cout << "Lab 5, team number 8\n";
    std::cout << "Variants: 5.1=2, 5.2=2, 5.3=2, 5.4=2, 5.5=2, 5.6=2, 5.7=2, 5.8=2, 5.9=3\n";

    int task = -1;
    while (task != 0) {
        std::cout << "\n"
                  << "1 - Lab5.1\n"
                  << "2 - Lab5.2\n"
                  << "3 - Lab5.3\n"
                  << "4 - Lab5.4\n"
                  << "5 - Lab5.5\n"
                  << "6 - Lab5.6\n"
                  << "7 - Lab5.7\n"
                  << "8 - Lab5.8\n"
                  << "9 - Lab5.9\n"
                  << "0 - Exit\n"
                  << "Task = ";

        if (!(std::cin >> task)) {
            return 1;
        }

        switch (task) {
        case 1: task1(); break;
        case 2: task2(); break;
        case 3: task3(); break;
        case 4: task4(); break;
        case 5: task5(); break;
        case 6: task6(); break;
        case 7: task7(); break;
        case 8: task8(); break;
        case 9: task9(); break;
        case 0: break;
        default: std::cout << "wrong task\n"; break;
        }
    }

    return 0;
}
